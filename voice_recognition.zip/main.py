# main.py
from gui import VoiceApp

if __name__ == "__main__":
    app = VoiceApp()
    app.mainloop()
